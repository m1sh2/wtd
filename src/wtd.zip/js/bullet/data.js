'use strict';

(function(wtd, win, doc, $){
  wtd.BULL = [];
  wtd.bullets = [];
})(WTD, window, document, jQuery)






















